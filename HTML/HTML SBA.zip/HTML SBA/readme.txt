The first page for the website is the login page. Which checks to make sure that the fields are not empty upon submit.
After hitting the submit button you are sent to the table page which is populated using javascript.
Alternately, you can click the register new user link to be sent to the registration page.
The registration page will check each input for different criteria on submit.
If all criteria are met it will send you back to the login page.
The clear button will reload the page to clear any information entered into the input fields.