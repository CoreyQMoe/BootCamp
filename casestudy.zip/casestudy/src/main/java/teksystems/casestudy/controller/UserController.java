package teksystems.casestudy.controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import teksystems.casestudy.database.dao.UserDAO;
import teksystems.casestudy.database.entity.User;
import teksystems.casestudy.formbean.RegisterFormBean;
import teksystems.casestudy.formbean.SearchFormBean;
import teksystems.casestudy.service.UserService;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;

@Slf4j
@Controller
public class UserController {

    @Autowired
    private UserDAO userDAO;
    @Autowired
    UserService userService;

    /**
     * controller for entry point of user registration.
     * does nothing but route to page
     */
    @RequestMapping(value = "/user/register", method = RequestMethod.GET)
    public ModelAndView register() throws Exception {
        ModelAndView response = new ModelAndView();
        response.setViewName("user/register");

        //all these 2 lines do is seed model with empty form
        RegisterFormBean form = new RegisterFormBean();
        response.addObject("form", form);

        return response;
    }

    //is a create or edit if the id field is populated in the bean
    @RequestMapping(value = "/user/registerSubmit", method = RequestMethod.POST)
    public ModelAndView registerSubmit(@Valid RegisterFormBean form, BindingResult bindingResult) throws Exception {
        ModelAndView response = new ModelAndView();

        HashMap errors = new HashMap();
        if (bindingResult.hasErrors()) {
            for (ObjectError error : bindingResult.getAllErrors()) {
                errors.put(((FieldError) error).getField(), error.getDefaultMessage());
                log.info(((FieldError) error).getField() + " " + error.getDefaultMessage());
            }

            response.addObject("formErrors", errors);

            response.setViewName("redirect:/user/register");
            return response;
        }


        //fill user if there is an id in the form -- assuming we are doing an edit
        User user = userDAO.findById(form.getId());

        user.setEmail(form.getEmail());
        user.setFirstName(form.getFirstName());
        user.setLastName(form.getLastName());
        user.setPassword(form.getPassword());

        userDAO.save(user);

        log.info("Form " + form.toString());

        //Instead of showing a view, we want to redirect to the edit page
        //edit page is responsible for loading data
        response.setViewName("redirect:/user/edit/" + user.getId());
        return response;
    }

    @GetMapping("/user/edit/{userId}")
    public ModelAndView editUser(@PathVariable("userId") Integer userId) throws Exception {
        ModelAndView response = new ModelAndView();
        response.setViewName("user/register");

        User user = userDAO.findById(userId);

        RegisterFormBean form = new RegisterFormBean();

        form.setEmail(user.getEmail());
        form.setFirstName(user.getFirstName());
        form.setLastName(user.getLastName());
        form.setPassword(user.getPassword());
        form.setConfirmPassword(user.getPassword());
        form.setId(user.getId());

        response.addObject("form", form);

        return response;
    }
// Done without a formbean
    @GetMapping("/user/search")
    public ModelAndView search(@RequestParam(required = false, name="search") String search) throws Exception {
        ModelAndView response = new ModelAndView();
        response.setViewName("user/search");

        if(StringUtils.isBlank(search)) {
            log.info("Search criteria cannot be blank");
        } else {
            List<User> users = userDAO.findByFirstNameIgnoreCaseContaining(search);
            response.addObject("users", users);
        }
        response.addObject("search", search);
        return response;
    }
}

